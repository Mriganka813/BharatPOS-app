class ShareService {
  const ShareService();

  // ///
  // static const platform = MethodChannel('native.magicstep.dev/share');

  // ///
  // Future<void> sharePdfToWhatsapp({
  //   required String filePath,
  //   required String subject,
  //   required String text,
  //   required String shareText,
  // }) async {
  //   try {
  //     await platform.invokeMethod('shareToWhatsapp', {
  //       'filePath': filePath,
  //       'subject': subject,
  //       'text': text,
  //       'shareText': shareText,
  //     });
  //   } on PlatformException {
  //     rethrow;
  //   }
  // }
}
