import 'package:flutter/material.dart';

class ColorsConst {
  const ColorsConst();
  static const primaryColor = Color(0xff0047FF);
}
