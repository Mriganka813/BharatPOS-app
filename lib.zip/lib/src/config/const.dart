class Const {
  const Const();

  ///
  static const apiUrl = 'https://cube-fpqiy.ondigitalocean.app';
  // static const apiUrl = 'https://cube-backend.onrender.com';
  // static const apiUrl = 'https://api.getshopos.com';
  // 'https://0e57-2401-4900-1cc4-5080-2dcb-b2b1-1250-458c.ngrok.io';
  static const apiV1Url = apiUrl + '/api/v1';
}
